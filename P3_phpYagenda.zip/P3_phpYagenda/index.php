<?php
// index.php
include('v/1inicioLogin.php');
?>